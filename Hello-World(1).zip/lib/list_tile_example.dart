import 'package:flutter/material.dart';
import 'package:helloworld/second_screen.dart';

class ListTileExample extends StatefulWidget {
  const ListTileExample({Key? key}) : super(key: key);

  @override
  _ListTileExampleState createState() => _ListTileExampleState();
}

class _ListTileExampleState extends State<ListTileExample> {
  String name = '';
  String email = '';
  String phoneNumber = '';
  String personalID = '';
  String address = '';
  String additionalInfo = '';

  bool checkBoxValue = false; // Nilai awal checkbox

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'PERSONAL FORM',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        children: <Widget>[
          _buildFormField('Full Name', 'Enter your name', name, (value) {
            setState(() {
              name = value;
            });
          }),
          _buildFormField('Email', 'Your Email', email, (value) {
            setState(() {
              email = value;
            });
          }),
          _buildRowWithVerification(''),
          _buildFormField('Personal ID Number', 'Value', phoneNumber, (value) {
            setState(() {
              phoneNumber = value;
            });
          }),
          _buildFormField('Address', 'Enter your text here', personalID,
              (value) {
            setState(() {
              personalID = value;
            });
          }),
          _buildFormFieldWithCheckbox('Choose a Date', 'Select date', address,
              (value) {
            setState(() {
              address = value;
            });
          }),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: ElevatedButton(
          onPressed: () {
            // Tambahkan logika untuk tombol "Submit" di sini
            {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => SecondScreen(
                    name: name,
                    email: email,
                    phoneNumber: phoneNumber,
                    personalID: personalID,
                    address: address,
                  ),
                ),
              );
            }
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.blue),
          ),
          child: Text('Submit'),
        ),
      ),
    );
  }

  Widget _buildFormField(String label, String hintText, String value,
      ValueChanged<String> onChanged) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          TextFormField(
            onChanged: onChanged,
            decoration: InputDecoration(
              hintText: hintText,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4.0),
                borderSide: BorderSide(
                  color: Colors.black,
                  width: 2,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRowWithVerification(String label) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child: TextFormField(
              decoration: InputDecoration(
                hintText: 'Enter phone number',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(4.0),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 8,
          ),
          Container(
            width: 100,
            margin: EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4.0),
              border: Border.all(
                color: Colors.blue,
                width: 2,
              ),
              color: Colors.white,
            ),
            child: ElevatedButton(
              onPressed: null,
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.transparent),
                elevation: MaterialStateProperty.all(0),
              ),
              child: Text('Verify', style: TextStyle(color: Colors.blue)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormFieldWithCheckbox(String label, String hintText,
      String value, ValueChanged<String> onChanged) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          TextFormField(
            onChanged: onChanged,
            decoration: InputDecoration(
              hintText: hintText,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4.0),
                borderSide: BorderSide(
                  color: Colors.black,
                  width: 2,
                ),
              ),
            ),
          ),
          CheckboxListTile(
            title: Text(
              'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.',
              style: TextStyle(fontSize: 14), // Style teks checkbox
            ),
            value: checkBoxValue,
            onChanged: (newValue) {
              setState(() {
                checkBoxValue = newValue ?? false;
              });
            },
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.all(0), // Hapus padding bawaan
          ),
        ],
      ),
    );
  }
}
