import 'package:flutter/material.dart';

class SecondScreen extends StatelessWidget {
  final String name;
  final String email;
  final String phoneNumber;
  final String personalID;
  final String address;

  SecondScreen({
    required this.name,
    required this.email,
    required this.phoneNumber,
    required this.personalID,
    required this.address,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'List Personal Data',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black,
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          child: DataTable(
            columnSpacing: 16,
            columns: [
              DataColumn(label: Text('Field')),
              DataColumn(label: Text('Value')),
            ],
            rows: [
              DataRow(cells: [
                DataCell(Text('Name')),
                DataCell(Text(name)),
              ]),
              DataRow(cells: [
                DataCell(Text('Email')),
                DataCell(Text(email)),
              ]),
              DataRow(cells: [
                DataCell(Text('Phone Number')),
                DataCell(Text(phoneNumber)),
              ]),
              DataRow(cells: [
                DataCell(Text('Personal ID')),
                DataCell(Text(personalID)),
              ]),
              DataRow(cells: [
                DataCell(Text('Address')),
                DataCell(Text(address)),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
